import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {randomUUID} from 'node:crypto';

export const KIT_ROOT=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
export function inside(root,file){const relative=path.relative(root,file);if(relative.startsWith('..'+path.sep)||relative==='..'||path.isAbsolute(relative))throw Error('路径必须位于agent-video-kit练习目录内');return file;}
export async function existingFile(root,file,maxBytes=200*1024*1024){const absolute=inside(path.resolve(root),path.resolve(file)),real=await fs.realpath(absolute);inside(path.resolve(root),real);const stat=await fs.stat(real);if(!stat.isFile()||stat.size>maxBytes)throw Error('材料必须是大小符合要求的普通文件');return real;}
export async function readJSON(root,file){const safe=await existingFile(root,file,1024*1024);const data=JSON.parse(await fs.readFile(safe,'utf8'));if(!data||typeof data!=='object'||Array.isArray(data))throw Error('JSON最外层必须是对象');return data;}
export async function safeDirectory(root,directory){const absolute=inside(path.resolve(root),path.resolve(directory));let ancestor=absolute;while(true){try{inside(path.resolve(root),await fs.realpath(ancestor));break;}catch(e){if(e.code!=='ENOENT')throw e;const parent=path.dirname(ancestor);if(parent===ancestor)throw e;ancestor=parent;}}await fs.mkdir(absolute,{recursive:true});inside(path.resolve(root),await fs.realpath(absolute));return absolute;}
export async function outputFile(root,file){const absolute=inside(path.resolve(root),path.resolve(file));await safeDirectory(root,path.dirname(absolute));try{await fs.lstat(absolute);throw Error('输出已存在，请使用新版本文件名；不会覆盖原文件');}catch(e){if(e.code!=='ENOENT')throw e;}return absolute;}
export async function writeNewJSON(root,file,data){const out=await outputFile(root,file);await fs.writeFile(out,JSON.stringify(data,null,2)+'\n',{flag:'wx',mode:0o600});return out;}
export async function updateJSON(root,file,data){await existingFile(root,file,1024*1024);const temp=inside(root,path.join(path.dirname(file),'.record-'+randomUUID()+'.json'));await fs.writeFile(temp,JSON.stringify(data,null,2)+'\n',{flag:'wx',mode:0o600});try{await fs.rename(temp,file);}catch(e){await fs.rm(temp,{force:true});throw e;}}
export async function apiKey(root){if(process.env.MINIMAX_API_KEY?.trim())return process.env.MINIMAX_API_KEY.trim();const file=path.join(root,'.env.local');try{await existingFile(root,file,8192);const text=await fs.readFile(file,'utf8');const lines=text.split(/\r?\n/).filter(l=>/^\s*MINIMAX_API_KEY\s*=/.test(l));if(lines.length!==1)return '';return lines[0].slice(lines[0].indexOf('=')+1).trim().replace(/^(["'])(.*)\1$/,'$2');}catch(e){if(e.code==='ENOENT')return '';throw e;}}
export const isMain=url=>Boolean(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(url));
