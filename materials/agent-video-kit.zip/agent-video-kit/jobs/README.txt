收费请求提交后在此保存真实task_id。
submitting/submission-uncertain/rejected都不表示生成成功，也不会自动重试。
先在官方任务记录核对；不同尝试使用新的镜号后缀，失败同样记费用。
